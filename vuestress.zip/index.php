<?php 

	header('Location: /panel/login.php');

?>

<?php
 require('/panel/xwaf.php');
 $xWAF = new xWAF();
 $xWAF->start();
?>  