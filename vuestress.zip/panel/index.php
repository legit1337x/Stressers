<?php 

	header('Location: login.php');

?>

<?php
 require('xwaf.php');
 $xWAF = new xWAF();
 $xWAF->start();
?>  