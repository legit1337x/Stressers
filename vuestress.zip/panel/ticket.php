<?php
header("Location: https://t.me/champssh");
exit;
?>
